Layout is based on the default layout that comes on the ergodox infinity. Focused mostly on making ctl and alt easy to reach. I spend most my day working in Eclipse which has just so many 3 key shortcuts.

* Removed numpad keys from symbol layer (I don't use them)
* Added arrow keys under h, j, k, l on symbol layer. vi movement keys!
* Added a few macros for eclipse hotkeys that I used all the time
* Added calc button on symbol layer
* tap vs hold on tab and \. Gives alt, ctl and shift on both sides of the keyboard

