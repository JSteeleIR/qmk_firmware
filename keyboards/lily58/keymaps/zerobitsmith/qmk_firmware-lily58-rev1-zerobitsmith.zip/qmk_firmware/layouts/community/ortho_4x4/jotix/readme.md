# Jotix ortho 4x4 keymap

![keymap](https://i.imgur.com/e67yN7x.jpg)

Enter is 'Lower' on hold.

