# skullY's Clueboard Layout

This layout is what I (@skullydazed) use on my personal Clueboards. I mostly use it for programming, CAD, and general typing.

On boards with audio I have faux-clicky enabled. I've tuned it to values I find pleasing, they kinda remind me of the "talking" in Mike Tyson's Punch Out.
