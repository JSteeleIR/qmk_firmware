Dvorak support, plover support, gaming support

I'm used to the Kinesis, so originally I was just going to patch up
the thumb keys to be more familiar. But the ergodox is really well
suited to NKRO support in Plover, so I added a layer for that, and
then I remembered that dvorak can be really annoying for video
games (try to reach WASD), so I added a layer for that.

The result is probably a bit idiosyncratic, but it works for me.

(I also don't have any press/hold distinction keys, because that
confuses my fuzzy little brain.)

Contributed by seebs (seebs@seebs.net)
